<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
require_once "config.php";
?>
 
<!DOCTYPE html>
<html lang="en">
<?php include('php/header.php'); ?>
<body>
<div id="wrapper">
    <?php include('php/menu.php'); ?>

				
			
            <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        
                    </div>
                    
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h1 class="page-header"><h1>Hi, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b>. Welcome to our site.</h1></h1>
                            </div>
                            <div class="panel-body">
									<?php
										if(isset($_POST["submit"])){
											echo '<p> Dữ liệu đã được ghi. Để thay đổi hãy vào phần quản lý hồ sơ. </p>';
											echo '<p> Bạn đã thực hiện 25% công việc điền biểu mẫu. <a href="formation.php">Thực hiện bước tiếp theo </a>';
											
											
										}else{
											
									?>
                                    <div class="col-lg-6">
										<label> Quá trình học tập / Academic History </label>
                                        <form method="post" action="formation.php?confirm=1">
											<div class="row">
												<div class="col-lg-6">
													<div class="form-group">
														<p>15. Tên trường / School name</p>
														<input name="fullname" class="form-control">
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-2">
													<div class="form-group">
														<p>16. Lớp / Class</p>
														<input name="card_id"class="form-control">
													</div>
												</div>

												<div class="col-lg-6">
													<div class="form-group">
														<p>17. Địa chỉ / Address</p>
														<input name="card_id"class="form-control">
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-4">
													<div class="form-group">
														<p>18. Giáo viên chủ nhiệm / Head teacher</p>
														 <input name="fullname" class="form-control">
													</div>
												</div>
												<div class="col-lg-4">
													<div class="form-group">
														<p>19. Điện thoại hoặc email / Phone number or email</p>
														<input name="p_birth" class="form-control">
													</div>
												</div>
											</div>
                                            <div class="row">
												<div class="col-lg-3">
													<div class="form-group">
														<p>20. Năm tốt nghiệp / Year of high school graduation</p>
														<input name="nationality" class="form-control">
													</div>
												</div>												
											</div>
											<div class="row">
												<div class="col-lg-12">
													<div class="form-group">
														<p>21.Kết quả học tập THPT/ High school Academic results</p>
															<table class="table table-striped table-bordered table-hover">
																<thead>
																	<tr class="info">
																		<th width="20%" align="center">Kết quả theo học bạ / Result</th>
																		<th width="10%" align="center">Xếp loại / Grade</th>
																		<th width="10%" align="center"> ĐTB năm / Final GPA</th>
																		<th width="10%" align="center">Toán / Maths</th>
																		<th width="10%" align="center">Vật lý / Physics</th>
																		<th width="10%" align="center">Hóa học / Chemistry</th>
																		<th width="10%" align="center">Sinh học / Biology</th>
																		<th width="10%" align="center">Tin học / IT</th>
																		<th width="10%" align="center">Tiếng Anh / English</th>
																	</tr>
																</thead>             
																<tbody>
																	<tr >
																		<td>Lớp 10 hoặc tương đương / Grade 10 or equivalent</td>
																		<td><input name="p_birth" class="form-control"></td>
																		<td><input name="p_birth" class="form-control"></td>
																		<td><input name="p_birth" class="form-control"></td>
																		<td><input name="p_birth" class="form-control"></td>
																		<td><input name="p_birth" class="form-control"></td>
																		<td><input name="p_birth" class="form-control"></td>
																		<td><input name="p_birth" class="form-control"></td>
																		<td><input name="p_birth" class="form-control"></td>
																	</tr>
																	<tr>
																		<td>Lớp 11 hoặc tương đương / Grade 11 or equivalent</td>
																		<td><input name="p_birth" class="form-control"></td>
																		<td><input name="p_birth" class="form-control"></td>
																		<td><input name="p_birth" class="form-control"></td>
																		<td><input name="p_birth" class="form-control"></td>
																		<td><input name="p_birth" class="form-control"></td>
																		<td><input name="p_birth" class="form-control"></td>
																		<td><input name="p_birth" class="form-control"></td>
																		<td><input name="p_birth" class="form-control"></td>
																	</tr>
																	<tr>
																		<td>Lớp 12 hoặc tương đương / Grade 12 or equivalent</td>
																		<td><input name="p_birth" class="form-control"></td>
																		<td><input name="p_birth" class="form-control"></td>
																		<td><input name="p_birth" class="form-control"></td>
																		<td><input name="p_birth" class="form-control"></td>
																		<td><input name="p_birth" class="form-control"></td>
																		<td><input name="p_birth" class="form-control"></td>
																		<td><input name="p_birth" class="form-control"></td>
																		<td><input name="p_birth" class="form-control"></td>
																	</tr>
																</tbody>
															</table>
															<p> * Với thí sinh sẽ tốt nghiệp năm 2020, nếu chưa có điểm trung bình năm lớp 12, vui lòng điền và ghi rõ điểm trung bình học kỳ 1 năm lớp 12/ For candidate who will graduate from high school in 2019, please clearly mention the average mark of the 1st semester of Grade 12 in case the mark for full year is not released. </p>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-12">
													<div class="form-group">
														<p>22. Các thành tích nổi bật khác (học bổng, giải thưởng,..) / Awards or Distinctions</p>
														<textarea name="message" rows="5" cols="110"></textarea>
													</div>
												</div>												
											</div>
											
										
											</br>
                                            <button type="submit"  name="submit" class="btn btn-default">Nhập / Submission</button>
                                        </form>
                                    </div>
										<?php }?>
                                </div>
                                <!-- /.row (nested) -->
                            </div>
                            <!-- /.panel-body -->
                        </div>
                        <!-- /.panel -->
                    </div>
                    <!-- /.col-lg-12 -->
   

        </div>
    </div>
    
</body>
</html>