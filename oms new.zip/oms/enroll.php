<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
require_once "config.php";
?>
 
<!DOCTYPE html>
<html lang="en">
<?php include('php/header.php'); ?>
<body>
<div id="wrapper">
    <?php include('php/menu.php'); ?>

				
			
            <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        
                    </div>
                    
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h1 class="page-header"><h1>Hi, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b>. Welcome to our site.</h1></h1>
                            </div>
                            <div class="panel-body">
									<?php
										if(isset($_POST["submit"])){
											echo '<p> Dữ liệu đã được ghi. Để thay đổi hãy vào phần quản lý hồ sơ. </p>';
											echo '<p> Bạn đã thực hiện 25% công việc điền biểu mẫu. <a href="formation.php">Thực hiện bước tiếp theo </a>';
											
											
										}elseif (isset($_POST["begin"])) {
											$query = "INSERT INTO form(user_id,status,grade) values(".$_SESSION['id'].",'on going','Bachelor')";
											mysqli_query($link, $query);
									?>
                                    <div class="col-lg-6">
										<label> Thông tin cá nhân / Personal Information </label>
                                        <form method="post" action="enroll.php?confirm=1">
											<div class="row">
												<div class="col-lg-6">
													<div class="form-group">
														<p>1. Họ và tên / Fullname</p>
														<input name="fullname" class="form-control">
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-4">
													<div class="form-group">
														<p>2. Số CMT / Card ID</p>
														<input name="card_id"class="form-control">
													</div>

												</div>
												<div class="col-lg-3">
													<div class="form-group">
														<p>Ngày cấp / Issued date</p>
														<input name="d_issued" type="date" name="date">
													</div>
												</div>
												<div class="col-lg-3">
													<div class="form-group">
														<p>Nơi cấp / Issued place</p>
														<input name="p_issued" class="form-control">
													</div>
												</div>
											</div>
                                            <div class="row">
												<div class="col-lg-3">
													<div class="form-group">
														<p>3. Ngày sinh / Date of birth</p>
														<input name="dob" type="date" name="date">
													</div>
												</div>
												<div class="col-lg-3">
													<div class="form-group">
														<p>4. Giới tính / Gender</p>
														 <select name="gender" class="form-control">
															<option>Nam / Male</option>
															<option>Nữ / Female</option>
														</select>
													</div>
												</div>
												<div class="col-lg-4">
													<div class="form-group">
														<p>5. Nơi sinh / Birth place</p>
														<input name="p_birth" class="form-control">
													</div>
												</div>
											</div>
                                            <div class="row">
												<div class="col-lg-5">
													<div class="form-group">
														<p>6. Quốc tịch / Nationality</p>
														<input name="nationality" class="form-control">
													</div>
												</div>
												<div class="col-lg-5">
													<div class="form-group">
														<p>7. Dân tộc / Ethnicity</p>
														<input name="ethnicity" class="form-control">
													</div>
												</div>
												
											</div>
											
                                            <div class="row">
												<div class="form-group">
													<div class="col-lg-10">
														<p>8. Địa chỉ gửi thư/ Current mailing address for correspondence</p>
														<input name="address" class="form-control">
													</div>
												</div>
											</div>
											
											
											
											<div class="row">
												<div class="form-group">
													<div class="col-lg-10">
															</br>
															<p>9. Hộ khẩu thường trú / Permanent resident address</p>
														 <div class="row">
															<div class="col-lg-3">
																<p> Số nhà / House No. </p>
																<input name="a_house"class="form-control">
															</div>
															<div class="col-lg-5">
																<p> Đường / Street </p>
																<input name="a_street" class="form-control">
															</div>
															<div class="col-lg-4">
																<p> Phường, xã / Commune </p>
																<input name="a_commune" class="form-control">
															</div>
														</div>
														<div class="row">
															<div class="col-lg-5">
																<p> Quận, huyện / District </p>
																<input name="a_district" class="form-control">
															</div>
															<div class="col-lg-5">
																<p> Tỉnh, thành phố / Province </p>
																<input name="a_province" class="form-control">
															</div>
														</div>
													</div>
												</div>
											</div>
											</br>
											 <div class="row">
												<div class="form-group">
														<div class="col-lg-5">
															<p>10. Di động / Mobile phone: </p>
															<input name="mobile" class="form-control">
														</div>
														<div class="col-lg-5">
															<p>11. Email: </p>
															<input name="email" class="form-control">
														</div>
												</div>
											</div>
											</br>
											 <div class="row">
												<div class="form-group">
														<div class="col-lg-5">
															<p>12. Điện thoại / Home phone: </p>
															<input name"phone" class="form-control">
														</div>
														<div class="col-lg-5">
															<p>13. Số di động của bố mẹ / Parent's mobile no.: </p>
															<input name="p_phone" class="form-control">
														</div>
												</div>
											</div>
											</br>
											 <div class="row">
												<div class="form-group">
														<div class="col-lg-5">
															<p>14. Tình trạng hôn nhân / Marital status: </p>
															<select name="status" class="form-control">
																<option>Độc thân / Single</option>
																<option>Đã kết hôn / Married</option>
															</select>
														</div>
														
												</div>
											</div>
											</br>
                                            <button type="submit"  name="submit" class="btn btn-default">Nhập / Submission</button>
                                        </form>
                                    </div>
										<?php }
										else{
										?>
										
											<form method="post" action="enroll.php">
												<p> Hãy bấm vào đây để bắt đầu tạo form đăng ký </p>
												<button type="submit"  name="begin" class="btn btn-default">Tạo mới / Create</button>
											</form>
										<?php
										}
										?>
                                </div>
                                <!-- /.row (nested) -->
                            </div>
                            <!-- /.panel-body -->
                        </div>
                        <!-- /.panel -->
                    </div>
                    <!-- /.col-lg-12 -->
   

        </div>
    </div>
    
</body>
</html>