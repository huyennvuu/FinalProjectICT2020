<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
require_once "config.php";
?>
 
<!DOCTYPE html>
<html lang="en">
<?php include('php/header.php'); ?>
<body>
<div id="wrapper">
    <?php include('php/menu.php'); ?>

				
			
            <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        
                    </div>
                    
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h1 class="page-header"><h1>Hi, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b>. Welcome to our site.</h1></h1>
                            </div>
                            <!-- /.panel-body -->
							<div class="panel-body">
									<?php
										
									?>
                                    <div class="col-lg-8">
                                        <form method="post" action="enroll.php?confirm=1">
											<div class="row">
												<div class="col-lg-6">
													<div class="form-group">
														<?php 
															$query = "SELECT * FROM form WHERE user_id =".$_SESSION["id"];
															$result = mysqli_query($link, $query);
														?>
														
														<div class="table-responsive">
															<table class="table">
																<thead>
																	<tr class="info">
																		<th>No.</th>
																		<th>Grade</th>
																		<th>Time and Date</th>
																		<th>Status</th>
																		<th>Approved</th>
																	</tr>
																</thead>             
																<tbody>
																	
																	
														<?php				
																		
															
																		
															
															$i = 1;
															if (mysqli_num_rows($result) > 0){
																while ($row = mysqli_fetch_array($result)){
																	if ($i % 2 == 0){
																		echo '<tr class="success">';
																	}else{
																		echo '<tr class="warning">';
																	}
																		echo '<td>'.$i.'</td>';	
																		echo '<td>'.$row["grade"].'</td>';
																		echo '<td>'.$row["created_at"].'</td>';
																		echo '<td> <a href=edit?id='.$row["id"].'>'.$row["isDone"].'</a></td>';
																		echo '<td>'.$row["isApproved"].'</td>';
																	$i = $i+1;
																}
															}

															?>
																</tbody>
															</table>
														</div>

													</div>
												</div>
											</div>
                                            
                                        </form>
                                    </div>
										
                                </div>
                                <!-- /.row (nested) -->
                            </div>
                        </div>
                        <!-- /.panel -->
                    </div>
                    <!-- /.col-lg-12 -->
   

        </div>
    </div>
    
</body>
</html>